package org.optaplanner.examples.vehiclerouting.domain.timewindowed;

import org.optaplanner.examples.vehiclerouting.domain.VehicleRoutingSolution;

public class TimeWindowedVehicleRoutingSolution extends VehicleRoutingSolution {

    public TimeWindowedVehicleRoutingSolution() {
        super();
    }

    public TimeWindowedVehicleRoutingSolution(long id) {
        super(id);
    }

}
